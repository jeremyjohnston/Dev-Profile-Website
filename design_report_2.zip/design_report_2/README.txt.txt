Read me for Design Report 2 and Source files, IndieGameDevZone.com
-----------------------------------------------------------------

The design doc contains descriptions, use case diagrams, use case stories, class diagrams, and other documentation.

The source folder has .aspx files for each webpage, a master page for overall style. At the moment all .css style is contain in a single .css but as we add
code this may be separated out into separate .css files for menu and other pages.

Yet to come is code behind files such as c sharp and mysql configuration files for the database and ranking algorithms.

