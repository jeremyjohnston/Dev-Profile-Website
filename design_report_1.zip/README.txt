README for design report
---

"design report.docx" contains report, with embedded use case and class diagram
.vsd files are UI designs (save missing portfolio and about page), and .vsd for use cases matching image in "design report.docx"

-- Jeremy Johnston